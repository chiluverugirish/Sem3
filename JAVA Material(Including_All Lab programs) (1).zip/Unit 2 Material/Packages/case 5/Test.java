import pack1.telecom.Employee;
//import static pack1.telecom.Employee.tele;
//import pack2.MNC.Employee;

public class Test 
{
	public static void main(String args[])
	{
		Employee e1=new Employee(201,"Nikitha");
		Employee.tele();
		pack2.MNC.Employee e2=new pack2.MNC.Employee(105,"Hima Bindu",3);
		e2.org();
		
	}
}
