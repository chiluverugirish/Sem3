package organization;  
public class Employee
{  
    public void display() 
	{  
        System.out.println("Welcome to KMIT");  
    }  
}