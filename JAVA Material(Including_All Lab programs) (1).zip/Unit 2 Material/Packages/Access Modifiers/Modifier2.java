//Access modifier: Default

package Google;
public class Modifier2
{  
 public static void main(String args[])
 {  
   Employee2 e1=new Employee2();  
   System.out.println(e1.id);  
   e1.display(); 
 }  
}  