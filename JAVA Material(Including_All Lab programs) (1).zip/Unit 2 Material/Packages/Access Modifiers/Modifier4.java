//Public
import Google.Employee4;
public class Modifier4
{  
 public static void main(String args[])
 {  
   Employee4 e1=new Employee4();  
   System.out.println(e1.id);  
   e1.display(); 
 }
}