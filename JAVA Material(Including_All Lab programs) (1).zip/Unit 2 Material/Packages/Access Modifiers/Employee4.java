//Public
package Google;
public class Employee4
{
	public int id=101;
	public Employee4()
	{
		System.out.println("Default constructor called");
	} 
	public void display()
	{
		System.out.println("ID:"+id);
	}  
}






