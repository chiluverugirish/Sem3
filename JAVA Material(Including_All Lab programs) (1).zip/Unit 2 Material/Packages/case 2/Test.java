import telecom.Employee;

class Test 
{
	public static void main(String args[])
	{
		Employee e=new Employee(28,"Neha");

		Employee e2=new Employee(101,"Bindu");
	}
}
