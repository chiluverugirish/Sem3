interface Personelbanking
{
	float reporate=7.5f; //by default interface variable is public static final

	void lending_funds();
	void checkClearence();
	int Deposit_Amt(int amt);
	int withDraw_Amt(int amt);
}