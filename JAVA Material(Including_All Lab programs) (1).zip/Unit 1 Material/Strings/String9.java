//String case conversion
public class String9 {
   public static void main(String[] args) 
   {
      String str = "string abc touppercase ";
      String strUpper = str.toUpperCase();
      String strLower = strUpper.toLowerCase();
      System.out.println("Original String: " + str);
      System.out.println("String changed to upper case: " + strUpper);
      System.out.println("String changed to lower case: " + strLower);	  
   }
}