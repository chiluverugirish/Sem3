class Test35
{
    public static void main(String args[])
     {
	
	int[] a=new int[6];  //integer array
	a[0]=10;
	a[1]=20;
	a[2]=30;

	      for(int a1:a)
	       {
		System.out.println(a1);

   	         }
	
	}
}