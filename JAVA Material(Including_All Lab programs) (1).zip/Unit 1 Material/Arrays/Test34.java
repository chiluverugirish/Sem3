class Test34
{
    public static void main(String args[])
     {
		
	float[] a=new float[6];  //float array

	      for(float a1:a)
	    {
		System.out.println(a1);

   	     }
	
	boolean[] b=new boolean[3];  //boolean array

	      for(boolean b1:b)
	    {
		System.out.println(b1);

   	     }
	String A[]=new String[3]; //string  array

	      for(String c1: A)
	    {
		System.out.println(c1);

   	     }
	
       }

}