/* One Dimenstional Array  using for loop*/

class Test32
{
    public static void main(String args[])
     {
	int[] a={10,20,30,40};

   	for(int i=0;i<a.length;i++)
	{
	   
//	System.out.println(a[i]);

	System.out.println("index:"+i+ "-"+a[i]);
	
	  }
      }
}
