/* One Dimenstional Array*/

class Test31
{
    public static void main(String args[])
     {
	int[] a;
	a=new int[] {10,20,30,40};

   	System.out.println(a[0]);
	System.out.println(a[1]);
	System.out.println(a[2]);
	System.out.println(a[3]);

      }
}
