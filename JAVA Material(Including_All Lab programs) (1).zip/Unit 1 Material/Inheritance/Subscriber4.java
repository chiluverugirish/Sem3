class Subscriber4 
{
	Subscriber4()
	{
		System.out.println("Base class constructor gets called");
	}
	void makeCall()
	{
		System.out.println("Base class makecall called");
	}
	void receiveCall()
	{
		System.out.println("Base class receivecall called");
	}
}
