class Subscriber7
{
	Subscriber7()
	{
		System.out.println("Base class constructor gets called");
	}
	
	static void makeCall()
	{
		System.out.println("Base class makecall called");
	}
	void receiveCall()
	{
		System.out.println("Base class receivecall called");
	}
}
