//Stack operations in LinkedList
import java.util.*;

class List4
{
	public static void main(String args[]) 
	{
		LinkedList<String> list = new LinkedList<String>();

		list.push("C");
		list.push("B");
		list.push("A");
		System.out.println(list);//

		list.pop();//
		System.out.println(list);//

	}
}

