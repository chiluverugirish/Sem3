Demo1: StringTokenizer Class example program
Demo2: BitSet Class example program
Demo3: BitSet Class example program with and(), or(), xor() methods
Demo4: Random Class example program
Demo5: Date class example Program
Demo6: Calendar class example program
Demo7: Formatter class example program
Demo8: Formatting time and date
